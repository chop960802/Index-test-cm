package com.example.storage

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
  entities =
    [
      EmployeeEntity::class,
      ShiftEntity::class,
      DepartmentEntity::class,
      DutyTypeEntity::class,
      RosterAssignmentEntity::class,
      AttendanceRecordEntity::class,
      AppMetaEntity::class,
      SafetySnapshotEntity::class,
      OfficeIndexEntity::class,
      IctCategoryEntity::class,
      IctSubCategoryEntity::class,
      IctEntryEntity::class,
    ],
  version = 5,
  exportSchema = false,
)
abstract class BivashDatabase : RoomDatabase() {
  abstract fun dao(): BivashDao

  companion object {
    @Volatile private var instance: BivashDatabase? = null

    val MIGRATION_1_2 =
      object : Migration(1, 2) {
        override fun migrate(db: SupportSQLiteDatabase) {
          db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS `office_index` (
              `id` TEXT NOT NULL,
              `integerValue` INTEGER NOT NULL,
              `textValue` TEXT NOT NULL,
              `category` TEXT NOT NULL,
              `subCategory` TEXT NOT NULL,
              `notes` TEXT NOT NULL,
              `createdAt` INTEGER NOT NULL,
              `updatedAt` INTEGER NOT NULL,
              PRIMARY KEY(`id`)
            )
            """.trimIndent()
          )
        }
      }

    val MIGRATION_2_3 =
      object : Migration(2, 3) {
        override fun migrate(db: SupportSQLiteDatabase) {
          db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS `ict_categories` (
              `id` TEXT NOT NULL,
              `name` TEXT NOT NULL,
              `description` TEXT NOT NULL,
              `createdAt` INTEGER NOT NULL,
              `updatedAt` INTEGER NOT NULL,
              PRIMARY KEY(`id`)
            )
            """.trimIndent()
          )
          db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS `ict_sub_categories` (
              `id` TEXT NOT NULL,
              `categoryId` TEXT NOT NULL,
              `name` TEXT NOT NULL,
              `unitLabel` TEXT NOT NULL,
              `createdAt` INTEGER NOT NULL,
              `updatedAt` INTEGER NOT NULL,
              PRIMARY KEY(`id`)
            )
            """.trimIndent()
          )
          db.execSQL(
            "CREATE INDEX IF NOT EXISTS `index_ict_sub_categories_categoryId` ON `ict_sub_categories` (`categoryId`)"
          )
          db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS `ict_entries` (
              `id` TEXT NOT NULL,
              `categoryId` TEXT NOT NULL,
              `subCategoryId` TEXT,
              `valueText` TEXT NOT NULL,
              `numericValue` REAL,
              `note` TEXT NOT NULL,
              `categoryNameSnapshot` TEXT NOT NULL,
              `subCategoryNameSnapshot` TEXT NOT NULL,
              `recordedAt` INTEGER NOT NULL,
              `updatedAt` INTEGER NOT NULL,
              PRIMARY KEY(`id`)
            )
            """.trimIndent()
          )
          db.execSQL(
            "CREATE INDEX IF NOT EXISTS `index_ict_entries_categoryId` ON `ict_entries` (`categoryId`)"
          )
          db.execSQL(
            "CREATE INDEX IF NOT EXISTS `index_ict_entries_subCategoryId` ON `ict_entries` (`subCategoryId`)"
          )
        }
      }

    val MIGRATION_3_4 =
      object : Migration(3, 4) {
        override fun migrate(db: SupportSQLiteDatabase) {
          db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS `departments` (
              `id` TEXT NOT NULL,
              `name` TEXT NOT NULL,
              `description` TEXT NOT NULL,
              `isActive` INTEGER NOT NULL,
              `createdAt` INTEGER NOT NULL,
              `updatedAt` INTEGER NOT NULL,
              PRIMARY KEY(`id`)
            )
            """.trimIndent()
          )
          db.execSQL("ALTER TABLE `duty_types` ADD COLUMN `departmentId` TEXT NOT NULL DEFAULT ''")
          db.execSQL("ALTER TABLE `duty_types` ADD COLUMN `defaultShiftId` TEXT")
          db.execSQL("ALTER TABLE `roster_assignments` ADD COLUMN `departmentId` TEXT")
          db.execSQL("ALTER TABLE `attendance_records` ADD COLUMN `departmentId` TEXT")
          db.execSQL(
            "ALTER TABLE `attendance_records` ADD COLUMN `departmentNameSnapshot` TEXT NOT NULL DEFAULT ''"
          )
          val now = System.currentTimeMillis()
          db.execSQL(
            "INSERT OR IGNORE INTO `departments` (`id`, `name`, `description`, `isActive`, `createdAt`, `updatedAt`) VALUES ('dept_computer', 'Computer', 'Default department (editable & deletable)', 1, $now, $now)"
          )
        }
      }

    val MIGRATION_4_5 =
      object : Migration(4, 5) {
        override fun migrate(db: SupportSQLiteDatabase) {
          db.execSQL("ALTER TABLE `employees` ADD COLUMN `defaultDepartmentId` TEXT")
        }
      }

    fun getInstance(context: Context): BivashDatabase {
      return instance
        ?: synchronized(this) {
          instance
            ?: Room.databaseBuilder(
                context.applicationContext,
                BivashDatabase::class.java,
                "bivash_index.db",
              )
              .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5)
              .build()
              .also { instance = it }
        }
    }
  }
}
