package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Clear
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.logic.DateUtils
import com.example.models.OfficeIndexEntry
import com.example.ui.components.DetailMetaPair
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.ReferenceDetailCard
import com.example.ui.components.SolidPillTag
import com.example.ui.components.TintedPillTag
import com.example.ui.components.VibrantFeatureBanner
import com.example.ui.state.OfficeIndexUiState
import com.example.ui.theme.FloralVariant
import com.example.ui.theme.GradientPaletteRegistry

@Composable
fun OfficeIndexScreen(
  state: OfficeIndexUiState,
  onBack: () -> Unit,
  onSearchTextChange: (String) -> Unit,
  onSelectCategory: (String?) -> Unit,
  onSaveEntry: (String?, Int, String, String, String, String) -> Unit,
  onDeleteEntry: (OfficeIndexEntry) -> Unit,
  modifier: Modifier = Modifier,
) {
  var showCreateDialog by remember { mutableStateOf(false) }
  var editingEntry by remember { mutableStateOf<OfficeIndexEntry?>(null) }
  var deletingEntry by remember { mutableStateOf<OfficeIndexEntry?>(null) }

  if (showCreateDialog || editingEntry != null) {
    OfficeIndexEditDialog(
      initial = editingEntry,
      onSave = { intVal, textVal, category, subCategory, notes ->
        onSaveEntry(editingEntry?.id, intVal, textVal, category, subCategory, notes)
        showCreateDialog = false
        editingEntry = null
      },
      onDismiss = {
        showCreateDialog = false
        editingEntry = null
      },
    )
  }

  deletingEntry?.let { target ->
    AlertDialog(
      onDismissRequest = { deletingEntry = null },
      title = { Text("Delete Index Entry?") },
      text = {
        Text(
          text = "Remove '${target.textValue}' (${target.category} / ${target.subCategory}) from Office Index?",
          style = MaterialTheme.typography.bodyMedium,
        )
      },
      confirmButton = {
        Button(
          onClick = {
            onDeleteEntry(target)
            deletingEntry = null
          },
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
          modifier = Modifier.testTag("confirm_delete_office_index_button"),
        ) {
          Text("Delete")
        }
      },
      dismissButton = { TextButton(onClick = { deletingEntry = null }) { Text("Cancel") } },
    )
  }

  val bannerPalette = GradientPaletteRegistry.paletteForCard("office_index_banner", 1)
  val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.5f

  Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
    Column(modifier = Modifier.fillMaxSize().widthIn(max = 860.dp)) {
      Box(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
        VibrantFeatureBanner(
          title = "Office Index",
          subtitle = "${state.allEntriesCount} entries · ${state.categories.size} categories",
          palette = bannerPalette,
          floralVariant = FloralVariant.BOTANICAL_VINE,
          icon = Icons.Outlined.Inventory2,
          leadingContent = {
            Surface(
              shape = RoundedCornerShape(12.dp),
              color = Color(0x470B1020),
              border = BorderStroke(1.dp, Color.White.copy(alpha = 0.35f)),
            ) {
              IconButton(
                onClick = onBack,
                modifier = Modifier.minimumInteractiveComponentSize().testTag("office_index_back_button"),
              ) {
                Icon(
                  imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                  contentDescription = "Back to Dashboard",
                  tint = Color.White,
                )
              }
            }
          },
          trailingContent = {
            Button(
              onClick = { showCreateDialog = true },
              colors =
                ButtonDefaults.buttonColors(
                  containerColor = Color(0xE6FFFFFF),
                  contentColor = Color(0xFF0F172A),
                ),
              modifier = Modifier.height(44.dp).testTag("add_office_index_button"),
            ) {
              Icon(Icons.Outlined.Add, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Add", fontWeight = FontWeight.Bold)
            }
          },
        )
      }

      LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        item {
          OutlinedTextField(
            value = state.searchText,
            onValueChange = onSearchTextChange,
            label = { Text("Filter by text, category, sub-category, or number") },
            leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
            trailingIcon =
              if (state.searchText.isNotBlank()) {
                {
                  IconButton(onClick = { onSearchTextChange("") }) {
                    Icon(Icons.Outlined.Clear, contentDescription = "Clear filter")
                  }
                }
              } else null,
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("office_index_search_input"),
          )
        }

        if (state.categories.isNotEmpty()) {
          item {
            Row(
              modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
              horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              FilterChip(
                selected = state.selectedCategory == null,
                onClick = { onSelectCategory(null) },
                label = { Text("All Categories") },
              )
              state.categories.forEachIndexed { idx, cat ->
                val catPalette = GradientPaletteRegistry.paletteForCard(cat, idx)
                val catAccent = catPalette.colors.first()
                val selected = state.selectedCategory == cat
                FilterChip(
                  selected = selected,
                  onClick = {
                    onSelectCategory(if (selected) null else cat)
                  },
                  label = {
                    Text(
                      text = cat,
                      fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                    )
                  },
                  border =
                    FilterChipDefaults.filterChipBorder(
                      enabled = true,
                      selected = selected,
                      borderColor = catAccent.copy(alpha = 0.45f),
                      selectedBorderColor = catAccent,
                      borderWidth = 1.dp,
                      selectedBorderWidth = 1.5.dp,
                    ),
                  colors =
                    FilterChipDefaults.filterChipColors(
                      containerColor = catAccent.copy(alpha = if (isDark) 0.18f else 0.10f),
                      labelColor = MaterialTheme.colorScheme.onSurface,
                      selectedContainerColor = catAccent.copy(alpha = if (isDark) 0.34f else 0.22f),
                      selectedLabelColor = MaterialTheme.colorScheme.onSurface,
                    ),
                )
              }
            }
          }
        }

        if (state.entries.isEmpty()) {
          item {
            EmptyStateCard(
              title = "No Office Index entries",
              message = "Tap Add to record an entry with Integer, Text, Category, and Sub-Category fields.",
              icon = Icons.Outlined.Inventory2,
            )
          }
        } else {
          itemsIndexed(state.entries, key = { _, entry -> entry.id }) { idx, entry ->
            OfficeIndexEntryCard(
              entry = entry,
              paletteIndex = idx,
              onEdit = { editingEntry = entry },
              onDelete = { deletingEntry = entry },
            )
          }
        }

        item { Spacer(modifier = Modifier.height(16.dp)) }
      }
    }
  }
}

@Composable
private fun OfficeIndexEntryCard(
  entry: OfficeIndexEntry,
  paletteIndex: Int,
  onEdit: () -> Unit,
  onDelete: () -> Unit,
) {
  val cardPalette = GradientPaletteRegistry.paletteForCard(entry.category, paletteIndex)
  val accent = cardPalette.colors.first()
  ReferenceDetailCard(
    accentColor = accent,
    modifier = Modifier.testTag("office_index_card_${entry.id}"),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Text(
        text = entry.textValue,
        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
        maxLines = 2,
        overflow = TextOverflow.Ellipsis,
        modifier = Modifier.weight(1f).padding(end = 8.dp),
      )
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(2.dp),
      ) {
        SolidPillTag(
          text = entry.category,
          containerColor = accent,
        )
        IconButton(
          onClick = onEdit,
          modifier = Modifier.minimumInteractiveComponentSize(),
        ) {
          Icon(Icons.Outlined.Edit, contentDescription = "Edit ${entry.textValue}")
        }
        IconButton(
          onClick = onDelete,
          modifier = Modifier.minimumInteractiveComponentSize(),
        ) {
          Icon(
            imageVector = Icons.Outlined.DeleteOutline,
            contentDescription = "Delete ${entry.textValue}",
            tint = MaterialTheme.colorScheme.error,
          )
        }
      }
    }

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(18.dp),
    ) {
      DetailMetaPair(label = "Value", value = entry.integerValue.toString())
      DetailMetaPair(label = "Sub-Category", value = entry.subCategory)
    }

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(18.dp),
    ) {
      DetailMetaPair(label = "Updated", value = DateUtils.formatTimestamp(entry.updatedAt))
    }

    if (entry.notes.isNotBlank()) {
      TintedPillTag(text = entry.notes, accentColor = cardPalette.colors[1])
    }
  }
}

@Composable
private fun OfficeIndexEditDialog(
  initial: OfficeIndexEntry?,
  onSave: (Int, String, String, String, String) -> Unit,
  onDismiss: () -> Unit,
) {
  var integerInput by remember(initial) {
    mutableStateOf(initial?.integerValue?.toString() ?: "0")
  }
  var textValue by remember(initial) { mutableStateOf(initial?.textValue ?: "") }
  var category by remember(initial) { mutableStateOf(initial?.category ?: "") }
  var subCategory by remember(initial) { mutableStateOf(initial?.subCategory ?: "") }
  var notes by remember(initial) { mutableStateOf(initial?.notes ?: "") }

  val parsedInt = integerInput.trim().toIntOrNull()
  val isValid =
    parsedInt != null &&
      textValue.isNotBlank() &&
      category.isNotBlank() &&
      subCategory.isNotBlank()

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text(if (initial == null) "Add Office Index Entry" else "Edit Office Index Entry") },
    text = {
      Column(
        modifier = Modifier.verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        OutlinedTextField(
          value = integerInput,
          onValueChange = { integerInput = it },
          label = { Text("Integer Value") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          isError = integerInput.isNotBlank() && parsedInt == null,
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("office_index_integer_input"),
        )
        OutlinedTextField(
          value = textValue,
          onValueChange = { textValue = it },
          label = { Text("Text / Label") },
          placeholder = { Text("Safety Helmet Batch A") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("office_index_text_input"),
        )
        OutlinedTextField(
          value = category,
          onValueChange = { category = it },
          label = { Text("Category") },
          placeholder = { Text("Equipment") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("office_index_category_input"),
        )
        OutlinedTextField(
          value = subCategory,
          onValueChange = { subCategory = it },
          label = { Text("Sub-Category") },
          placeholder = { Text("PPE") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("office_index_subcategory_input"),
        )
        OutlinedTextField(
          value = notes,
          onValueChange = { notes = it },
          label = { Text("Notes (optional)") },
          maxLines = 3,
          modifier = Modifier.fillMaxWidth().testTag("office_index_notes_input"),
        )
      }
    },
    confirmButton = {
      Button(
        onClick = {
          onSave(parsedInt ?: 0, textValue, category, subCategory, notes)
        },
        enabled = isValid,
        modifier = Modifier.testTag("save_office_index_button"),
      ) {
        Text("Save")
      }
    },
    dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
  )
}
