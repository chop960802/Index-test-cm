package com.example.models

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class OfficeIndexEntry(
  val id: String,
  val integerValue: Int,
  val textValue: String,
  val category: String,
  val subCategory: String,
  val notes: String = "",
  val createdAt: Long,
  val updatedAt: Long,
)

data class OfficeIndexSummary(
  val totalEntries: Int = 0,
  val distinctCategories: Int = 0,
  val integerTotal: Int = 0,
  val recentEntries: List<OfficeIndexEntry> = emptyList(),
)
